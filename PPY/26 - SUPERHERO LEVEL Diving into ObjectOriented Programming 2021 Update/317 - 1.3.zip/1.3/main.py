class Email:
    def __init__(self, subject, body):
        self.subject = subject
        self.body = body

    def send(self, to):
        print(f"Sending email with subject: {self.subject} and body: {self.body} to: {to}")


if __name__ == "__main__":
    greeting_email = Email("Welcome!", "Welcome to epicpython.io!")
    greeting_email.subject = "Greeting!"
    greeting_email.send("bob@nasa.gov")
    greeting_email.send("liz@buckingham.uk")
